package ru.manus.modelbridge;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public final class ModelBridgeClient implements ClientModInitializer {
    private static KeyMapping openSelectorKey;

    @Override
    public void onInitializeClient() {
        ModeController.load();
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.tryBuild("modelbridge", "keys")
        );
        openSelectorKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.modelbridge.open", InputConstants.KEY_I, category)
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openSelectorKey.consumeClick()) {
                if (!(client.gui.screen() instanceof ModelSelectorScreen)) {
                    client.gui.setScreen(new ModelSelectorScreen(client.gui.screen()));
                }
            }
            ModeController.applyIfNeeded();
        });
    }

    public static Minecraft minecraft() {
        return Minecraft.getInstance();
    }
}
