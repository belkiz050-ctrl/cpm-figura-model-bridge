package ru.manus.modelbridge;

public enum ModelMode {
    AUTO("auto", "Авто"),
    CPM("cpm", "Только CPM"),
    FIGURA("figura", "Только Figura"),
    NONE("none", "Нет доступных модов");

    private final String id;
    private final String label;

    ModelMode(String id, String label) {
        this.id = id;
        this.label = label;
    }

    public String id() {
        return id;
    }

    public String label() {
        return label;
    }

    public static ModelMode fromId(String id) {
        for (ModelMode mode : values()) {
            if (mode.id.equalsIgnoreCase(id)) return mode;
        }
        return AUTO;
    }
}
