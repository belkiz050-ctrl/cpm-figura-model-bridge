package ru.manus.modelbridge;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.List;

public final class ModelSelectorScreen extends Screen {
    private static final int BUTTON_WIDTH = 280;
    private static final int BUTTON_HEIGHT = 30;
    private static final int BUTTON_GAP = 6;
    private static final int TEXTURE_WIDTH = 374;
    private static final int TEXTURE_HEIGHT = 40;

    private static final int AUTO_ACCENT = 0xFFFFD36B;
    private static final int CPM_ACCENT = 0xFFE1E1E1;
    private static final int FIGURA_ACCENT = 0xFF78F078;
    private static final int HOVER_ACCENT = 0xFFE8F5FF;

    private static final Identifier AUTO_TEXTURE = Identifier.fromNamespaceAndPath(
            "modelbridge", "textures/gui/button_auto.png");
    private static final Identifier CPM_TEXTURE = Identifier.fromNamespaceAndPath(
            "modelbridge", "textures/gui/button_cpm.png");
    private static final Identifier FIGURA_TEXTURE = Identifier.fromNamespaceAndPath(
            "modelbridge", "textures/gui/button_figura.png");

    private final Screen parent;
    private final List<ModeButton> modeButtons = new ArrayList<>();

    public ModelSelectorScreen(Screen parent) {
        super(Component.literal("CPM + Figura — модели"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        modeButtons.clear();
        int totalHeight = BUTTON_HEIGHT * 3 + BUTTON_GAP * 2;
        int left = (this.width - BUTTON_WIDTH) / 2;
        int top = this.height / 2 - totalHeight / 2;

        addModeButton(left, top, ModelMode.AUTO, true, AUTO_TEXTURE, AUTO_ACCENT);
        addModeButton(left, top + BUTTON_HEIGHT + BUTTON_GAP, ModelMode.CPM,
                ModeController.isCpmLoaded(), CPM_TEXTURE, CPM_ACCENT);
        addModeButton(left, top + (BUTTON_HEIGHT + BUTTON_GAP) * 2, ModelMode.FIGURA,
                ModeController.isFiguraLoaded(), FIGURA_TEXTURE, FIGURA_ACCENT);

        addRenderableWidget(Button.builder(Component.literal("Закрыть"), button -> onClose())
                .bounds(this.width / 2 - 60, this.height / 2 + 116, 120, 20)
                .build());
    }

    private void addModeButton(int x, int y, ModelMode mode, boolean available,
                               Identifier texture, int accent) {
        Button button = Button.builder(Component.literal(mode.label()), pressed -> {
                    ModeController.setMode(mode);
                    if (minecraft != null) minecraft.gui.setScreen(new ModelSelectorScreen(parent));
                })
                .bounds(x, y, BUTTON_WIDTH, BUTTON_HEIGHT)
                .build();
        button.active = available;
        addRenderableWidget(button);
        modeButtons.add(new ModeButton(x, y, mode, texture, accent, available));
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, width, height, 0x90000000);
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);

        graphics.centeredText(font, title, width / 2, height / 2 - 78, 0xFFFFFF);
        String cpm = ModeController.isCpmLoaded() ? "CPM: установлен" : "CPM: не найден";
        String figura = ModeController.isFiguraLoaded() ? "Figura: установлена" : "Figura: не найдена";
        graphics.centeredText(font, Component.literal(cpm + "    |    " + figura),
                width / 2, height / 2 - 57, 0xB8B8B8);

        for (ModeButton modeButton : modeButtons) {
            graphics.blit(RenderPipelines.GUI_TEXTURED, modeButton.texture,
                    modeButton.x, modeButton.y, 0.0f, 0.0f,
                    BUTTON_WIDTH, BUTTON_HEIGHT, TEXTURE_WIDTH, TEXTURE_HEIGHT);

            if (!modeButton.available) {
                graphics.fill(modeButton.x, modeButton.y,
                        modeButton.x + BUTTON_WIDTH, modeButton.y + BUTTON_HEIGHT, 0xA0000000);
            }

            int labelColor = modeButton.available ? modeButton.accent : 0xFF888888;
            graphics.centeredText(font, Component.literal(modeButton.mode.label()),
                    modeButton.x + BUTTON_WIDTH / 2,
                    modeButton.y + (BUTTON_HEIGHT - 9) / 2,
                    labelColor);

            boolean selected = ModeController.selectedMode() == modeButton.mode;
            boolean hovered = mouseX >= modeButton.x && mouseX < modeButton.x + BUTTON_WIDTH
                    && mouseY >= modeButton.y && mouseY < modeButton.y + BUTTON_HEIGHT;
            if (selected) {
                drawButtonFrame(graphics, modeButton, modeButton.accent, true);
            } else if (hovered && modeButton.available) {
                drawButtonFrame(graphics, modeButton, HOVER_ACCENT, false);
            }
        }

        ModelMode effective = ModeController.effectiveMode();
        graphics.centeredText(font, Component.literal("Активный режим: " + effective.label()),
                width / 2, height / 2 + 82, 0xFFE8C0);
        graphics.centeredText(font, Component.literal("Авто: Figura для игрока с её аватаром, иначе CPM."),
                width / 2, height / 2 + 97, 0xA0A0A0);
    }

    private void drawButtonFrame(GuiGraphicsExtractor graphics, ModeButton button, int color, boolean selected) {
        int x = button.x;
        int y = button.y;
        int right = x + BUTTON_WIDTH;
        int bottom = y + BUTTON_HEIGHT;
        graphics.fill(x, y, right, y + 1, color);
        graphics.fill(x, bottom - 1, right, bottom, color);
        graphics.fill(x, y, x + 1, bottom, color);
        graphics.fill(right - 1, y, right, bottom, color);
        if (selected) {
            graphics.fill(x + BUTTON_WIDTH / 2 - 8, bottom - 3,
                    x + BUTTON_WIDTH / 2 + 8, bottom - 1, color);
        }
    }

    @Override
    public void onClose() {
        if (minecraft != null) minecraft.gui.setScreen(parent);
    }

    private record ModeButton(int x, int y, ModelMode mode, Identifier texture, int accent, boolean available) {
    }
}
