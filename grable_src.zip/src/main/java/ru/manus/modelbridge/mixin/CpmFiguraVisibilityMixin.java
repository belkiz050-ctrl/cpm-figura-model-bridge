package ru.manus.modelbridge.mixin;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.manus.modelbridge.ModeController;

@Mixin(value = LivingEntityRenderer.class, priority = 900)
public abstract class CpmFiguraVisibilityMixin {
    @Shadow protected EntityModel<?> model;

    @Inject(
            method = "isBodyVisible(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;)Z",
            at = @At("RETURN"),
            cancellable = true,
            require = 1
    )
    private void modelbridge$keepFiguraPlayerBodyVisible(
            LivingEntityRenderState renderState,
            CallbackInfoReturnable<Boolean> callback
    ) {
        if (!(renderState instanceof AvatarRenderState)) return;
        boolean before = callback.getReturnValueZ();
        boolean useFigura = ModeController.shouldRenderFigura(renderState);
        boolean after = useFigura || before;
        ModeController.logBodyVisibility(renderState, before, after, useFigura);
        if (useFigura) callback.setReturnValue(true);
    }

    @Shadow
    public abstract Identifier getTextureLocation(LivingEntityRenderState renderState);

    @Inject(
            method = "getRenderType(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;ZZZ)Lnet/minecraft/client/renderer/rendertype/RenderType;",
            at = @At("HEAD"),
            cancellable = true,
            require = 1
    )
    private void modelbridge$preserveFiguraModel(
            LivingEntityRenderState renderState,
            boolean bodyVisible,
            boolean translucent,
            boolean glowing,
            CallbackInfoReturnable<RenderType> callback
    ) {
        if (!(renderState instanceof AvatarRenderState) || !ModeController.shouldRenderFigura(renderState)) return;

        Identifier texture = getTextureLocation(renderState);
        if (texture == null) {
            ModeController.logRenderType(renderState, bodyVisible, translucent, glowing, "null player texture");
            return;
        }

        RenderType renderType;
        if (translucent) {
            renderType = RenderTypes.entityTranslucentCull(texture);
        } else if (bodyVisible) {
            renderType = model.renderType(texture);
        } else if (glowing) {
            renderType = RenderTypes.outline(texture);
        } else {
            renderType = model.renderType(texture);
        }
        ModeController.logRenderType(renderState, bodyVisible, translucent, glowing, renderType.toString());
        callback.setReturnValue(renderType);
    }
}
