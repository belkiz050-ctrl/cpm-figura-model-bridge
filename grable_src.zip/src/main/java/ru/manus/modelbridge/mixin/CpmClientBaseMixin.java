package ru.manus.modelbridge.mixin;

import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.manus.modelbridge.ModeController;

@Pseudo
@Mixin(targets = "com.tom.cpm.client.ClientBase", remap = false)
public abstract class CpmClientBaseMixin {
    private static final String PLAYER_RENDER_PRE =
            "playerRenderPre(Lcom/tom/cpm/client/PlayerRenderStateAccess;Lnet/minecraft/client/model/player/PlayerModel;Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)V";
    private static final String RENDER_HAND =
            "renderHand(Lnet/minecraft/client/model/player/PlayerModel;)V";

    @Inject(method = PLAYER_RENDER_PRE, at = @At("HEAD"), cancellable = true, remap = false, require = 1)
    private void modelbridge$selectCpmPerPlayer(
            @Coerce Object playerStateAccess,
            PlayerModel playerModel,
            AvatarRenderState renderState,
            CallbackInfo callback
    ) {
        if (!ModeController.shouldRenderCpm(renderState)) callback.cancel();
    }

    @Inject(method = RENDER_HAND, at = @At("HEAD"), cancellable = true, remap = false, require = 1)
    private void modelbridge$selectCpmForLocalPlayer(PlayerModel playerModel, CallbackInfo callback) {
        if (!ModeController.shouldRenderCpmForLocalPlayer()) callback.cancel();
    }
}
