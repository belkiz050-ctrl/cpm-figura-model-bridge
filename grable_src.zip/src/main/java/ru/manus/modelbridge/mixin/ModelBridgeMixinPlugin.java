package ru.manus.modelbridge.mixin;

import net.fabricmc.loader.api.FabricLoader;
import org.objectweb.asm.tree.ClassNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import java.util.List;
import java.util.Set;

public final class ModelBridgeMixinPlugin implements IMixinConfigPlugin {
    private static final Logger LOGGER = LoggerFactory.getLogger("ModelBridge");

    @Override
    public void onLoad(String mixinPackage) {
    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        boolean cpmLoaded = FabricLoader.getInstance().isModLoaded("cpm");
        boolean figuraLoaded = FabricLoader.getInstance().isModLoaded("figura");
        boolean apply;
        if (mixinClassName.endsWith("CpmClientBaseMixin") || mixinClassName.endsWith("CpmNullRenderTypeMixin")) {
            apply = cpmLoaded;
        } else if (mixinClassName.endsWith("CpmFiguraVisibilityMixin")) {
            apply = cpmLoaded && figuraLoaded;
        } else if (mixinClassName.endsWith("FiguraSubmitCollectorMixin")) {
            apply = cpmLoaded && figuraLoaded;
        } else {
            return true;
        }
        LOGGER.info("Diagnostic: mixin gate class={} CPM={} Figura={} apply={}",
                mixinClassName, cpmLoaded, figuraLoaded, apply);
        return apply;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {
    }

    @Override
    public List<String> getMixins() {
        return null;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }
}
