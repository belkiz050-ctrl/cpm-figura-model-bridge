package ru.manus.modelbridge.mixin;

import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.SubmitNodeStorage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import ru.manus.modelbridge.ModelMode;
import ru.manus.modelbridge.ModeController;

import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * CPM wraps the vanilla SubmitNodeStorage in CPMSubmitNodeCollector. Figura's
 * FiguraSubmitUtils only submits its custom geometry when the collector is a
 * SubmitNodeStorage, so that wrapper makes Figura silently drop the avatar.
 * Restore the delegate only while Figura is the selected renderer.
 */
@Pseudo
@Mixin(targets = "org.figuramc.figura.utils.FiguraSubmitUtils", remap = false)
public abstract class FiguraSubmitCollectorMixin {
    private static final Logger LOGGER = LoggerFactory.getLogger("ModelBridge");
    private static final String CPM_COLLECTOR =
            "com.tom.cpm.client.CPMOrderedSubmitNodeCollector$CPMSubmitNodeCollector";
    private static final AtomicBoolean LOGGED_UNWRAP = new AtomicBoolean();
    private static final AtomicBoolean LOGGED_FAILURE = new AtomicBoolean();

    @ModifyVariable(
            method = "submit(Lnet/minecraft/client/renderer/SubmitNodeCollector;Lorg/figuramc/figura/model/rendering/nodeRenderer/FiguraSubmission;)V",
            at = @At("HEAD"),
            argsOnly = true,
            index = 0,
            remap = false,
            require = 0
    )
    private static SubmitNodeCollector modelbridge$restoreFiguraStorageCollector(SubmitNodeCollector collector) {
        ModelMode mode = ModeController.selectedMode();
        if (mode != ModelMode.AUTO && mode != ModelMode.FIGURA) return collector;
        if (collector == null || !collector.getClass().getName().equals(CPM_COLLECTOR)) return collector;

        try {
            Field delegateField = collector.getClass().getDeclaredField("collector");
            delegateField.setAccessible(true);
            Object delegate = delegateField.get(collector);
            if (delegate instanceof SubmitNodeStorage) {
                if (LOGGED_UNWRAP.compareAndSet(false, true)) {
                    LOGGER.info("Diagnostic: restored Figura SubmitNodeStorage through CPM collector in mode={}", mode.id());
                }
                return (SubmitNodeCollector) delegate;
            }
            if (LOGGED_FAILURE.compareAndSet(false, true)) {
                LOGGER.warn("Could not restore Figura collector: CPM delegate is {}",
                        delegate == null ? "null" : delegate.getClass().getName());
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            if (LOGGED_FAILURE.compareAndSet(false, true)) {
                LOGGER.warn("Could not restore Figura SubmitNodeStorage through CPM collector", exception);
            }
        }
        return collector;
    }
}
