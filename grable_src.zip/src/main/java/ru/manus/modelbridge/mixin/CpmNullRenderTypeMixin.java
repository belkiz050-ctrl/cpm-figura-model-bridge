package ru.manus.modelbridge.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.Model;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.texture.UvMapping;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.manus.modelbridge.ModeController;

@Pseudo
@Mixin(targets = "com.tom.cpm.client.CPMOrderedSubmitNodeCollector", remap = false)
public abstract class CpmNullRenderTypeMixin {
    private static final String SUBMIT_MODEL =
            "submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/rendertype/RenderType;IIILnet/minecraft/client/renderer/texture/UvMapping;I)V";

    @Inject(method = SUBMIT_MODEL, at = @At("HEAD"), cancellable = true, remap = false, require = 1)
    private void modelbridge$skipInvalidNullTypeSubmission(
            Model<?> model,
            @Coerce Object renderState,
            PoseStack poseStack,
            RenderType renderType,
            int light,
            int overlay,
            int tint,
            UvMapping uvMapping,
            int outlineColor,
            CallbackInfo callback
    ) {
        // Keep Figura's fallback/model-part submissions intact when CPM is gated off.
        if (renderType == null && ModeController.shouldRenderCpm(renderState)) callback.cancel();
    }
}
