package ru.manus.modelbridge;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ModeController {
    private static final Logger LOGGER = LoggerFactory.getLogger("ModelBridge");
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("modelbridge.properties");
    private static final Set<Integer> LOGGED_RENDER_DECISIONS = ConcurrentHashMap.newKeySet();
    private static final Set<Integer> LOGGED_BODY_VISIBILITY = ConcurrentHashMap.newKeySet();
    private static final Set<Integer> LOGGED_RENDER_TYPES = ConcurrentHashMap.newKeySet();
    private static ModelMode selectedMode = ModelMode.AUTO;
    private static ModelMode lastAppliedEffectiveMode;

    private ModeController() {
    }

    public static void load() {
        if (!Files.exists(CONFIG)) {
            LOGGER.info("Diagnostic: loaded mode={} (default; config file not found)", selectedMode.id());
            return;
        }
        Properties properties = new Properties();
        try (var input = Files.newInputStream(CONFIG)) {
            properties.load(input);
            selectedMode = ModelMode.fromId(properties.getProperty("mode", "auto"));
        } catch (IOException exception) {
            LOGGER.warn("Could not read ModelBridge settings; using Auto mode", exception);
            selectedMode = ModelMode.AUTO;
        }
        LOGGER.info("Diagnostic: loaded configured mode={}", selectedMode.id());
    }

    public static void setMode(ModelMode mode) {
        selectedMode = mode;
        LOGGED_RENDER_DECISIONS.clear();
        LOGGED_BODY_VISIBILITY.clear();
        LOGGED_RENDER_TYPES.clear();
        LOGGER.info("Diagnostic: user selected mode={}", mode.id());
        Properties properties = new Properties();
        properties.setProperty("mode", mode.id());
        try {
            Files.createDirectories(CONFIG.getParent());
            try (var output = Files.newOutputStream(CONFIG)) {
                properties.store(output, "CPM + Figura ModelBridge settings");
            }
        } catch (IOException exception) {
            LOGGER.warn("Could not save ModelBridge settings", exception);
        }
        applyIfNeeded();
    }

    public static ModelMode selectedMode() {
        return selectedMode;
    }

    public static ModelMode effectiveMode() {
        boolean cpm = isCpmLoaded();
        boolean figura = isFiguraLoaded();
        return switch (selectedMode) {
            case AUTO -> cpm && figura ? ModelMode.AUTO : cpm ? ModelMode.CPM : figura ? ModelMode.FIGURA : ModelMode.NONE;
            case CPM -> cpm ? ModelMode.CPM : figura ? ModelMode.FIGURA : ModelMode.NONE;
            case FIGURA -> figura ? ModelMode.FIGURA : cpm ? ModelMode.CPM : ModelMode.NONE;
            case NONE -> ModelMode.NONE;
        };
    }

    public static boolean shouldRenderFigura(Object playerRenderState) {
        if (!(playerRenderState instanceof AvatarRenderState state) || !isFiguraLoaded()) return false;

        boolean firstDecisionForPlayer = !LOGGED_RENDER_DECISIONS.contains(state.id);
        boolean avatarFound = selectedMode == ModelMode.AUTO || firstDecisionForPlayer
                ? hasFiguraAvatarForState(state)
                : false;
        boolean useFigura = switch (selectedMode) {
            case CPM, NONE -> false;
            case FIGURA -> true;
            case AUTO -> avatarFound;
        };

        if (LOGGED_RENDER_DECISIONS.add(state.id)) {
            LOGGER.info("Diagnostic: player decision stateId={} mode={} avatarFound={} useFigura={} figuraPanic={}",
                    state.id, selectedMode.id(), avatarFound, useFigura, figuraPanicState());
        }
        return useFigura;
    }

    public static void logBodyVisibility(Object renderState, boolean before, boolean after, boolean useFigura) {
        if (!(renderState instanceof AvatarRenderState state)) return;
        if (LOGGED_BODY_VISIBILITY.add(state.id)) {
            LOGGER.info("Diagnostic: body visibility stateId={} mode={} useFigura={} original={} final={}",
                    state.id, selectedMode.id(), useFigura, before, after);
        }
    }

    public static void logRenderType(Object renderState, boolean bodyVisible, boolean translucent, boolean glowing, String result) {
        if (!(renderState instanceof AvatarRenderState state)) return;
        if (LOGGED_RENDER_TYPES.add(state.id)) {
            LOGGER.info("Diagnostic: render type stateId={} mode={} bodyVisible={} translucent={} glowing={} result={}",
                    state.id, selectedMode.id(), bodyVisible, translucent, glowing, result);
        }
    }

    public static boolean shouldRenderCpm(Object playerRenderState) {
        if (!isCpmLoaded()) return false;
        return switch (selectedMode) {
            case CPM -> true;
            case FIGURA, NONE -> false;
            case AUTO -> !shouldRenderFigura(playerRenderState);
        };
    }

    public static boolean shouldRenderCpmForLocalPlayer() {
        if (!isCpmLoaded()) return false;
        return switch (selectedMode) {
            case CPM -> true;
            case FIGURA, NONE -> false;
            case AUTO -> !isFiguraLoaded() || !hasFiguraAvatarForLocalPlayer();
        };
    }

    public static boolean isCpmLoaded() {
        return FabricLoader.getInstance().isModLoaded("cpm");
    }

    public static boolean isFiguraLoaded() {
        return FabricLoader.getInstance().isModLoaded("figura");
    }

    public static void applyIfNeeded() {
        ModelMode effective = effectiveMode();
        boolean changed = effective != lastAppliedEffectiveMode;
        if (!changed && effective != ModelMode.CPM) return;
        lastAppliedEffectiveMode = effective;
        boolean panicTarget = effective == ModelMode.CPM;
        setFiguraPanic(panicTarget);
        if (changed) {
            LOGGER.info("Diagnostic: effective mode={} selected={} Figura panic target={} current={}",
                    effective.id(), selectedMode.id(), panicTarget, figuraPanicState());
        }
    }

    private static boolean hasFiguraAvatarForState(Object renderState) {
        if (renderState == null || !isFiguraLoaded()) return false;
        try {
            Class<?> manager = Class.forName("org.figuramc.figura.avatar.AvatarManager");
            for (Method method : manager.getDeclaredMethods()) {
                if (!method.getName().equals("getAvatar") || method.getParameterCount() != 1) continue;
                if (!method.getParameterTypes()[0].isInstance(renderState)) continue;
                method.setAccessible(true);
                return method.invoke(null, renderState) != null;
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            LOGGER.warn("Could not detect a Figura avatar for a player; preferring Figura to prevent overlapping models", exception);
            return true;
        }
        return false;
    }

    private static boolean hasFiguraAvatarForLocalPlayer() {
        if (!isFiguraLoaded()) return false;
        try {
            if (Minecraft.getInstance().player == null) return false;
            UUID uuid = Minecraft.getInstance().player.getUUID();
            Class<?> manager = Class.forName("org.figuramc.figura.avatar.AvatarManager");
            Method method = manager.getDeclaredMethod("getAvatarForPlayer", UUID.class);
            method.setAccessible(true);
            return method.invoke(null, uuid) != null;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            LOGGER.warn("Could not detect a Figura avatar for the local player; preferring Figura to prevent overlapping models", exception);
            return true;
        }
    }

    private static String figuraPanicState() {
        if (!isFiguraLoaded()) return "not-loaded";
        try {
            Class<?> manager = Class.forName("org.figuramc.figura.avatar.AvatarManager");
            Field field = manager.getDeclaredField("panic");
            field.setAccessible(true);
            return Boolean.toString(field.getBoolean(null));
        } catch (ReflectiveOperationException | RuntimeException exception) {
            return "unavailable";
        }
    }

    private static void setFiguraPanic(boolean panic) {
        if (!isFiguraLoaded()) return;
        try {
            Class<?> manager = Class.forName("org.figuramc.figura.avatar.AvatarManager");
            Field field = manager.getDeclaredField("panic");
            field.setAccessible(true);
            field.setBoolean(null, panic);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            LOGGER.warn("Could not synchronize Figura visibility with the selected model mode", exception);
        }
    }
}
